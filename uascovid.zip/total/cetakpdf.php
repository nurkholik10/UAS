<?php
require('../fpdf.php');
$pdf = new FPDF('l','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(190,7,'Data Donasi',0,1,'L');


$pdf->Cell(10,7,'',0,1); //space

$pdf->SetFont('Arial','B',10);
$pdf->Cell(50,8,'Jenis Alokasi',1,0,'C');
$pdf->Cell(70,8,'Jumlah Dana',1,0,'C');
$pdf->Cell(33,8,'Jumlah Transaksi',1,1,'C');

$pdf->SetFont('Arial','',10);

include '../koneksi.php';
$select = mysqli_query($koneksi, "SELECT * FROM apd ORDER BY id_apd DESC LIMIT 1");
while ($row = mysqli_fetch_array($select)){
    $pdf->Cell(50,8,$row['nm_alat'],1,0,'C');
    $pdf->Cell(70,8,$row['jml_donasi'],1,0,'C');
    $pdf->Cell(33,8,$row['jml_trans'],1,1,'C');    
}
$select = mysqli_query($koneksi, "SELECT * FROM logistik ORDER BY id_logistik DESC LIMIT 1");
while ($row = mysqli_fetch_array($select)){
    $pdf->Cell(50,8,$row['nm_alat'],1,0,'C');
    $pdf->Cell(70,8,$row['jml_donasi'],1,0,'C');
    $pdf->Cell(33,8,$row['jml_trans'],1,1,'C');    
}
$select = mysqli_query($koneksi, "SELECT * FROM kuota ORDER BY id_kuota DESC LIMIT 1");
while ($row = mysqli_fetch_array($select)){
    $pdf->Cell(50,8,$row['nm_alat'],1,0,'C');    
    $pdf->Cell(70,8,$row['jml_donasi'],1,0,'C');
    $pdf->Cell(33,8,$row['jml_trans'],1,1,'C');    
}
$select = mysqli_query($koneksi, "SELECT * FROM hs ORDER BY id_hs DESC LIMIT 1");
while ($row = mysqli_fetch_array($select)){
    $pdf->Cell(50,8,$row['nm_alat'],1,0,'C');
    $pdf->Cell(70,8,$row['jml_donasi'],1,0,'C');
    $pdf->Cell(33,8,$row['jml_trans'],1,1,'C');    
}
$select = mysqli_query($koneksi, "SELECT * FROM sembako ORDER BY id_sembako DESC LIMIT 1");
while ($row = mysqli_fetch_array($select)){
    $pdf->Cell(50,8,$row['nm_alat'],1,0,'C');
    $pdf->Cell(70,8,$row['jml_donasi'],1,0,'C');
    $pdf->Cell(33,8,$row['jml_trans'],1,1,'C');    
}

$pdf->Output();
?>
