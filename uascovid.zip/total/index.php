<!DOCTYPE html>
<html>

<head>
    <title>Data Donasi Terkumpul</title>
</head>

<body>
    <h2>List Donasi Terkumpul</h2>        
    <br />
    <br />
    <table border="1" cellspacing='0' cellpadding='6'>
        <tr>
            <th>Jenis Alokasi</th>
            <th>Jumlah Dana</th>
            <th>Jumlah Transaksi</th>           
        </tr>
        <?php
include "../koneksi.php";
$select = mysqli_query($koneksi,"SELECT * FROM apd ORDER BY id_apd DESC LIMIT 1");
while($row = mysqli_fetch_assoc($select)){
?>
        <tr>
            <td> <?php echo $row["nm_alat"]; ?> </td>
            <td> <?php echo $row["jml_donasi"]; ?> </td>            
            <td> <?php echo $row["jml_trans"]; ?> </td>            
        </tr>
        <?php
}$select = mysqli_query($koneksi,"SELECT * FROM logistik ORDER BY id_logistik DESC LIMIT 1");
while($row = mysqli_fetch_assoc($select)){
?>
        <tr>
            <td> <?php echo $row["nm_alat"]; ?> </td>
            <td> <?php echo $row["jml_donasi"]; ?> </td>            
            <td> <?php echo $row["jml_trans"]; ?> </td>            
        </tr>
        <?php
}$select = mysqli_query($koneksi,"SELECT * FROM kuota ORDER BY id_kuota DESC LIMIT 1");
while($row = mysqli_fetch_assoc($select)){
?>
        <tr>
            <td> <?php echo $row["nm_alat"]; ?> </td>
            <td> <?php echo $row["jml_donasi"]; ?> </td>            
            <td> <?php echo $row["jml_trans"]; ?> </td>            
        </tr>
        <?php
}$select = mysqli_query($koneksi,"SELECT * FROM hs ORDER BY id_hs DESC LIMIT 1");
while($row = mysqli_fetch_assoc($select)){
?>
        <tr>
            <td> <?php echo $row["nm_alat"]; ?> </td>
            <td> <?php echo $row["jml_donasi"]; ?> </td>            
            <td> <?php echo $row["jml_trans"]; ?> </td>            
        </tr>
        <?php
}$select = mysqli_query($koneksi,"SELECT * FROM sembako ORDER BY id_sembako DESC LIMIT 1");
while($row = mysqli_fetch_assoc($select)){
?>
        <tr>
            <td> <?php echo $row["nm_alat"]; ?> </td>
            <td> <?php echo $row["jml_donasi"]; ?> </td>            
            <td> <?php echo $row["jml_trans"]; ?> </td>            
        </tr>
        <?php
}
?>

    </table>
    <br />    
    <a href="cetakpdf.php">cetak pdf</a>&nbsp|&nbsp|&nbsp<a href="../index.php">Back to main menu</a><br>
</body>

</html>